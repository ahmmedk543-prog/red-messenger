import 'package:flutter/material.dart';

void main() => runApp(const RedMessengerApp());

class RedMessengerApp extends StatelessWidget {
  const RedMessengerApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ماسنجر الأحمر',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE50914)),
        scaffoldBackgroundColor: const Color(0xFFF8F8F8),
      ),
      home: const WelcomePage(),
    );
  }
}

const red = Color(0xFFE50914);

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFB00009), Color(0xFFE50914)]),
        ),
        child: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const CircleAvatar(radius: 54, backgroundColor: Colors.white, child: Icon(Icons.chat_bubble_rounded, size: 62, color: red)),
                const SizedBox(height: 24),
                const Text('ماسنجر الأحمر', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('تواصل مع أصدقائك بسهولة وأمان', style: TextStyle(color: Colors.white70, fontSize: 16)),
                const SizedBox(height: 50),
                SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPage())), style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: red), child: const Text('إنشاء حساب جديد', style: TextStyle(fontWeight: FontWeight.bold)))),
                const SizedBox(height: 14),
                SizedBox(width: double.infinity, height: 52, child: OutlinedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())), style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white)), child: const Text('تسجيل الدخول'))),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});
  @override State<RegisterPage> createState() => _RegisterPageState();
}
class _RegisterPageState extends State<RegisterPage> {
  final user = TextEditingController(); final pass = TextEditingController(); final name = TextEditingController(); final email = TextEditingController();
  bool obscure = true;
  @override void dispose(){user.dispose();pass.dispose();name.dispose();email.dispose();super.dispose();}
  void create(){ if(user.text.trim().isEmpty || pass.text.length < 6){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب اسم المستخدم وكلمة مرور من 6 أحرف على الأقل')));return;} Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => HomePage(displayName: name.text.trim().isEmpty ? user.text.trim() : name.text.trim(), username: user.text.trim())), (_) => false); }
  @override Widget build(BuildContext context){ return AuthScaffold(title:'إنشاء حساب', children:[field('اسم المستخدم', user, Icons.person_outline), field('كلمة المرور', pass, Icons.lock_outline, obscure: obscure, suffix: IconButton(onPressed:()=>setState(()=>obscure=!obscure),icon:Icon(obscure?Icons.visibility_outlined:Icons.visibility_off_outlined))), field('الاسم الظاهر (اختياري)', name, Icons.badge_outlined), field('البريد الإلكتروني (اختياري)', email, Icons.email_outlined), const SizedBox(height:12), SizedBox(width:double.infinity,height:52,child:FilledButton(onPressed:create, child:const Text('إنشاء حساب'))), TextButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const LoginPage())),child:const Text('لديك حساب بالفعل؟ تسجيل الدخول'))]); }
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage>{ final user=TextEditingController(); final pass=TextEditingController(); bool obscure=true; @override Widget build(BuildContext context){return AuthScaffold(title:'تسجيل الدخول',children:[field('اسم المستخدم',user,Icons.person_outline),field('كلمة المرور',pass,Icons.lock_outline,obscure:obscure,suffix:IconButton(onPressed:()=>setState(()=>obscure=!obscure),icon:Icon(obscure?Icons.visibility_outlined:Icons.visibility_off_outlined))),Align(alignment:Alignment.centerLeft,child:TextButton(onPressed:(){},child:const Text('نسيت كلمة المرور؟'))),SizedBox(width:double.infinity,height:52,child:FilledButton(onPressed:()=>Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>HomePage(displayName:user.text.isEmpty?'أحمد':user.text,username:user.text.isEmpty?'ahmed':user.text)),(_)=>false),child:const Text('تسجيل الدخول'))),TextButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const RegisterPage())),child:const Text('إنشاء حساب جديد'))]);}}

class AuthScaffold extends StatelessWidget { final String title; final List<Widget> children; const AuthScaffold({super.key,required this.title,required this.children}); @override Widget build(BuildContext context){return Scaffold(appBar:AppBar(title:Text(title),centerTitle:true,foregroundColor:red),body:Directionality(textDirection:TextDirection.rtl,child:ListView(padding:const EdgeInsets.all(24),children:[const SizedBox(height:20),Center(child:CircleAvatar(radius:40,backgroundColor:Color(0xFFFFE5E7),child:Icon(Icons.chat_bubble_rounded,size:42,color:red))),const SizedBox(height:18),...children])));}}

Widget field(String label, TextEditingController c, IconData icon,{bool obscure=false,Widget? suffix})=>Padding(padding:const EdgeInsets.only(bottom:14),child:TextField(controller:c,obscureText:obscure,textDirection:TextDirection.rtl,decoration:InputDecoration(labelText:label,prefixIcon:Icon(icon),suffixIcon:suffix,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14)))));

class HomePage extends StatefulWidget { final String displayName, username; const HomePage({super.key,required this.displayName,required this.username}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage>{int tab=0; final chats=[['أحمد محمد','السلام عليكم 👋','9:30 ص',2],['سارة علي','تم إرسال الصورة','8:45 ص',1],['عائلة العزاوي','محمد: متى الاجتماع؟','أمس',5],['نور المهدي','شكراً لك','أمس',0],['مصطفى','تمام','أمس',0]]; @override Widget build(BuildContext context){final pages=[ChatsPage(chats:chats),const PeoplePage(),const NotificationsPage(),ProfilePage(name:widget.displayName,username:widget.username)]; return Directionality(textDirection:TextDirection.rtl,child:Scaffold(body:pages[tab],bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),indicatorColor:const Color(0xFFFFE5E7),destinations:const[NavigationDestination(icon:Icon(Icons.chat_bubble_outline),selectedIcon:Icon(Icons.chat_bubble,color:red),label:'المحادثات'),NavigationDestination(icon:Icon(Icons.people_outline),selectedIcon:Icon(Icons.people,color:red),label:'الأشخاص'),NavigationDestination(icon:Icon(Icons.notifications_none),selectedIcon:Icon(Icons.notifications,color:red),label:'الإشعارات'),NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person,color:red),label:'حسابي')])));}}

class ChatsPage extends StatelessWidget { final List chats; const ChatsPage({super.key,required this.chats}); @override Widget build(BuildContext context){return Column(children:[AppBar(title:const Text('المحادثات'),actions:[IconButton(onPressed:(){},icon:const Icon(Icons.search)),IconButton(onPressed:(){},icon:const Icon(Icons.edit))]),Padding(padding:const EdgeInsets.all(12),child:TextField(decoration:InputDecoration(hintText:'بحث في المحادثات',prefixIcon:const Icon(Icons.search),filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderSide:BorderSide.none,borderRadius:BorderRadius.circular(14))))),Expanded(child:ListView.builder(itemCount:chats.length,itemBuilder:(c,i){final x=chats[i];return ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:16,vertical:4),leading:Stack(children:[CircleAvatar(backgroundColor:Colors.red.shade50,child:Text(x[0][0],style:const TextStyle(color:red,fontWeight:FontWeight.bold))),if(x[3]>0)Positioned(right:-2,top:-2,child:CircleAvatar(radius:9,backgroundColor:red,child:Text('${x[3]}',style:const TextStyle(color:Colors.white,fontSize:10))))]),title:Text(x[0],style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(x[1],maxLines:1,overflow:TextOverflow.ellipsis),trailing:Text(x[2],style:const TextStyle(fontSize:12,color:Colors.grey)),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>ChatPage(name:x[0]))));}))]);}}

class ChatPage extends StatefulWidget { final String name; const ChatPage({super.key,required this.name}); @override State<ChatPage> createState()=>_ChatPageState(); }
class _ChatPageState extends State<ChatPage>{final ctrl=TextEditingController(); final messages=[['السلام عليكم 👋',false],['وعليكم السلام، شلونك؟',true],['الحمدلله بخير',false]]; void send(){if(ctrl.text.trim().isEmpty)return;setState((){messages.add([ctrl.text.trim(),false]);ctrl.clear();});} @override Widget build(BuildContext context){return Scaffold(appBar:AppBar(title:Row(children:[const CircleAvatar(radius:17,child:Text('أ')),const SizedBox(width:8),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('أحمد محمد',style:TextStyle(fontSize:16,fontWeight:FontWeight.bold)),Text('متصل الآن',style:TextStyle(fontSize:11,color:Colors.green))])]),actions:[IconButton(onPressed:(){},icon:const Icon(Icons.call)),IconButton(onPressed:(){},icon:const Icon(Icons.more_vert))]),body:Column(children:[Expanded(child:ListView.builder(padding:const EdgeInsets.all(14),itemCount:messages.length,itemBuilder:(c,i){final m=messages[i];return Align(alignment:m[1]?Alignment.centerLeft:Alignment.centerRight,child:Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.symmetric(horizontal:14,vertical:10),decoration:BoxDecoration(color:m[1]?Colors.white:const Color(0xFFFFE0E3),borderRadius:BorderRadius.circular(18)),child:Text(m[0].toString())));})),SafeArea(child:Row(children:[IconButton(onPressed:(){},icon:const Icon(Icons.add_circle_outline,color:red)),Expanded(child:TextField(controller:ctrl,decoration:InputDecoration(hintText:'اكتب رسالة...',filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(25),borderSide:BorderSide.none)))),IconButton(onPressed:send,icon:const CircleAvatar(backgroundColor:red,child:Icon(Icons.send,color:Colors.white,size:19))) ]))]);}}

class PeoplePage extends StatelessWidget { const PeoplePage({super.key}); @override Widget build(BuildContext context){final names=['أحمد محمد','سارة علي','محمد خالد','نور المهدي','مصطفى أحمد','علي حسن'];return Column(children:[AppBar(title:const Text('الأشخاص'),actions:[IconButton(onPressed:(){},icon:const Icon(Icons.search))]),Padding(padding:const EdgeInsets.all(12),child:TextField(decoration:InputDecoration(hintText:'ابحث باسم المستخدم',prefixIcon:const Icon(Icons.search),filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderSide:BorderSide.none,borderRadius:BorderRadius.circular(14))))),ListTile(leading:const Icon(Icons.person_add_alt_1,color:red),title:const Text('إضافة صديق'),onTap:(){}),const Divider(),Expanded(child:ListView(children:names.map((n)=>ListTile(leading:CircleAvatar(backgroundColor:Colors.red.shade50,child:Text(n[0],style:const TextStyle(color:red))),title:Text(n),subtitle:Text('@${n.replaceAll(' ','').toLowerCase()}'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ChatPage(name:n)))) .toList()))]);}}

class NotificationsPage extends StatelessWidget { const NotificationsPage({super.key}); @override Widget build(BuildContext context){return Column(children:[AppBar(title:const Text('الإشعارات')),const ListTile(leading:CircleAvatar(backgroundColor:Color(0xFFFFE5E7),child:Icon(Icons.person_add,color:red)),title:Text('لديك طلب صداقة جديد'),subtitle:Text('من أحمد محمد')),const ListTile(leading:CircleAvatar(backgroundColor:Color(0xFFFFE5E7),child:Icon(Icons.message,color:red)),title:Text('رسالة جديدة'),subtitle:Text('من سارة علي'))]);}}

class ProfilePage extends StatelessWidget { final String name,username; const ProfilePage({super.key,required this.name,required this.username}); @override Widget build(BuildContext context){return Column(children:[AppBar(title:const Text('حسابي')),const SizedBox(height:24),const CircleAvatar(radius:46,backgroundColor:Color(0xFFFFE5E7),child:Icon(Icons.person,size:54,color:red)),const SizedBox(height:10),Text(name,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),Text('@$username',style:const TextStyle(color:Colors.grey)),const SizedBox(height:20),settings('الملف الشخصي',Icons.person_outline),settings('الخصوصية والأمان',Icons.lock_outline),settings('الإشعارات',Icons.notifications_none),settings('المظهر',Icons.palette_outlined),settings('المساعدة والدعم',Icons.help_outline),const Spacer(),TextButton.icon(onPressed:(){Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>const WelcomePage()),(_)=>false);},icon:const Icon(Icons.logout,color:red),label:const Text('تسجيل الخروج',style:TextStyle(color:red)))]);}}
Widget settings(String t,IconData i)=>ListTile(leading:Icon(i,color:red),title:Text(t),trailing:const Icon(Icons.chevron_left),onTap:(){});
